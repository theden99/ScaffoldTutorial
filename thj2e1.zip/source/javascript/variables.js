/*jshint esversion: 11, laxcomma:true, eqeqeq:true*/
/*jshint -W014,-W084,-W030,-W033*/
k.version = 0;
k.sheetName = "THJ2e";

//The attributes that are needed for all roll functions.
const rollGet = ['roll_state','whisper'];